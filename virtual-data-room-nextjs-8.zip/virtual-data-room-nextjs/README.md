# Vaultroom — Virtual Data Room prototype

## Requirements
- Node.js 20.9 or newer
- npm

## Run locally
1. Extract the project ZIP.
2. Open the extracted `virtual-data-room-nextjs` folder in VS Code.
3. Open Terminal → New Terminal.
4. Run:
   ```bash
   npm install
   npm run dev
   ```
5. Open http://localhost:3000

## Included
- Folder navigation, search, filtering, sorting
- Multi-select documents and CSV export
- Local demo file selection/upload flow
- In-app text/metadata preview
- Sensitivity tags and toggle
- Permission editor UI for Admin, Compliance Officer, Advisor, Auditor
- Activity audit drawer
- Light/dark mode and responsive layout

## Important
This is a frontend demo. Uploaded file content is not sent to a server; authentication, secure storage,
real permission enforcement, persistent audit logs, PDF rendering, and production authorization are not implemented.
Do not use real confidential documents in this prototype.
