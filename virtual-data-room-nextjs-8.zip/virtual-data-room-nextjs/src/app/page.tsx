"use client";

import { useMemo, useRef, useState } from "react";
import {
  Activity, Bell, ChevronDown, ChevronRight, Clock3, CloudUpload, Download,
  File, FileImage, FileJson, FileText, Folder, FolderPlus, Grid2X2, HardDrive,
  Home, LockKeyhole, Menu, MoreHorizontal, Moon, Search, Settings, ShieldCheck,
  SlidersHorizontal, Sun, Upload, Users, X, Eye, Pencil, Share2, Check, AlertTriangle
} from "lucide-react";

type Doc = {
  id: number; name: string; type: "PDF" | "DOC" | "XLS" | "IMG" | "JSON" | "TXT";
  folder: string; size: string; modified: string; owner: string;
  sensitivity: "Confidential" | "Internal Only" | "Public" | "Restricted";
  status: "Reviewed" | "Pending review" | "Flagged";
  preview: string;
};
type Event = { id:number; action:string; file:string; user:string; time:string };

const initialDocs: Doc[] = [
  {id:1,name:"Series A Investment Memo.pdf",type:"PDF",folder:"Fundraising",size:"2.4 MB",modified:"Oct 18, 2026",owner:"Sharon Reena",sensitivity:"Confidential",status:"Reviewed",preview:"Investment overview\\n\\nThis document outlines the Series A investment thesis, funding requirements, and proposed milestones.\\n\\nCOMPLIANCE REVIEW\\nPlease verify that all projected returns are clearly labelled as estimates and that risk disclosures are included."},
  {id:2,name:"Shareholder Agreement.docx",type:"DOC",folder:"Legal",size:"842 KB",modified:"Oct 17, 2026",owner:"Legal Team",sensitivity:"Restricted",status:"Pending review",preview:"SHAREHOLDER AGREEMENT\\n\\nThis agreement defines shareholder rights, transfer restrictions, and voting procedures.\\n\\nReview note: confirm the latest version with the legal team before sharing externally."},
  {id:3,name:"Q3 Financials.xlsx",type:"XLS",folder:"Finance",size:"1.8 MB",modified:"Oct 16, 2026",owner:"Finance Team",sensitivity:"Confidential",status:"Flagged",preview:"Q3 FINANCIAL SUMMARY\\n\\nRevenue: $4.2M\\nOperating expenses: $2.7M\\nNet operating income: $1.5M\\n\\nCOMPLIANCE REVIEW\\nConfirm these figures reconcile with the approved finance report."},
  {id:4,name:"Product Roadmap.png",type:"IMG",folder:"Product",size:"3.1 MB",modified:"Oct 15, 2026",owner:"Product Team",sensitivity:"Internal Only",status:"Reviewed",preview:"Mock image preview\\n\\nProduct roadmap — Q4 milestones, beta launch, customer feedback review, and general availability."},
  {id:5,name:"Due Diligence Checklist.json",type:"JSON",folder:"Legal",size:"16 KB",modified:"Oct 14, 2026",owner:"Compliance",sensitivity:"Internal Only",status:"Pending review",preview:'{\\n  "project": "Due Diligence",\\n  "items": ["Corporate records", "Financial statements", "IP review"],\\n  "owner": "Compliance",\\n  "status": "in-progress"\\n}'},
  {id:6,name:"Meeting Notes.txt",type:"TXT",folder:"General",size:"12 KB",modified:"Oct 12, 2026",owner:"Sharon Reena",sensitivity:"Public",status:"Reviewed",preview:"MEETING NOTES\\n\\n• Review outstanding diligence requests\\n• Confirm advisor access\\n• Schedule follow-up with finance\\n\\nNext meeting: Friday, 10:00 AM"},
];

const folders = ["All documents","Fundraising","Legal","Finance","Product","General"];
const roles = ["Admin","Compliance Officer","Advisor","Auditor"];
const fileIcon = (type:Doc["type"]) => type==="PDF" ? <FileText size={19} className="text-rose-500"/> : type==="IMG" ? <FileImage size={19} className="text-emerald-500"/> : type==="JSON" ? <FileJson size={19} className="text-amber-500"/> : type==="DOC" ? <FileText size={19} className="text-blue-500"/> : <File size={19} className="text-violet-500"/>;

export default function HomePage() {
  const [docs,setDocs] = useState<Doc[]>(initialDocs);
  const [folder,setFolder] = useState("All documents");
  const [query,setQuery] = useState("");
  const [sort,setSort] = useState("name");
  const [sensitivity,setSensitivity] = useState("All levels");
  const [selected,setSelected] = useState<number[]>([]);
  const [previewId,setPreviewId] = useState<number|null>(1);
  const [section,setSection] = useState("Documents");
  const [dark,setDark] = useState(false);
  const [showUpload,setShowUpload] = useState(false);
  const [showFolder,setShowFolder] = useState(false);
  const [showPermissions,setShowPermissions] = useState(false);
  const [showActivity,setShowActivity] = useState(false);
  const [newFolder,setNewFolder] = useState("");
  const [customFolders,setCustomFolders] = useState<string[]>([]);
  const [events,setEvents] = useState<Event[]>([
    {id:1,action:"Viewed",file:"Series A Investment Memo.pdf",user:"Sharon Reena",time:"2 min ago"},
    {id:2,action:"Permission changed",file:"Shareholder Agreement.docx",user:"Compliance Officer",time:"1 hour ago"},
    {id:3,action:"Flagged",file:"Q3 Financials.xlsx",user:"Auditor",time:"3 hours ago"},
  ]);
  const [toast,setToast] = useState("");
  const [role,setRole] = useState("Advisor");
  const [permission,setPermission] = useState("View");
  const uploadRef = useRef<HTMLInputElement>(null);
  const current = docs.find(d=>d.id===previewId) ?? null;
  const allFolders = [...folders.filter(f=>f!=="All documents"),...customFolders];
  const filtered = useMemo(()=>{
    const result = docs.filter(d=>(folder==="All documents"||d.folder===folder) &&
      (d.name.toLowerCase().includes(query.toLowerCase())||d.owner.toLowerCase().includes(query.toLowerCase())) &&
      (sensitivity==="All levels"||d.sensitivity===sensitivity));
    result.sort((a,b)=>sort==="name"?a.name.localeCompare(b.name):sort==="date"?b.id-a.id:sort==="type"?a.type.localeCompare(b.type):a.sensitivity.localeCompare(b.sensitivity));
    return result;
  },[docs,folder,query,sort,sensitivity]);
  function notify(message:string){setToast(message);window.setTimeout(()=>setToast(""),2600);}
  function addEvent(action:string,file:string){setEvents(old=>[{id:Date.now(),action,file,user:"Sharon Reena",time:"Just now"},...old]);}
  function toggleSelect(id:number){setSelected(old=>old.includes(id)?old.filter(x=>x!==id):[...old,id]);}
  function handleFiles(list:FileList|null){
    if(!list)return;
    const added:Doc[] = Array.from(list).map((f,i)=>{
      const ext=f.name.split(".").pop()?.toLowerCase()||"txt";
      const type:Doc["type"] = ext==="pdf"?"PDF":["doc","docx"].includes(ext)?"DOC":["xls","xlsx","csv"].includes(ext)?"XLS":["png","jpg","jpeg","webp"].includes(ext)?"IMG":ext==="json"?"JSON":"TXT";
      return {id:Date.now()+i,name:f.name,type,folder:folder==="All documents"?"General":folder,size:f.size>1024*1024?(f.size/1024/1024).toFixed(1)+" MB":Math.max(1,Math.round(f.size/1024))+" KB",modified:"Oct 18, 2026",owner:"Sharon Reena",sensitivity:"Internal Only",status:"Pending review",preview:`${f.name}\\n\\nLocal prototype preview. File content is not uploaded to a server.`};
    });
    setDocs(old=>[...added,...old]); added.forEach(d=>addEvent("Uploaded",d.name)); setShowUpload(false); notify(`${added.length} file(s) added to this demo`);
  }
  function exportCSV(){
    const rows=[["Name","Type","Folder","Size","Modified","Owner","Sensitivity","Status"],...filtered.map(d=>[d.name,d.type,d.folder,d.size,d.modified,d.owner,d.sensitivity,d.status])];
    const csv=rows.map(r=>r.map(v=>`"${v.replaceAll('"','""')}"`).join(",")).join("\\n");
    const a=document.createElement("a");a.href=URL.createObjectURL(new Blob([csv],{type:"text/csv"}));a.download="data-room-documents.csv";a.click();URL.revokeObjectURL(a.href);notify("CSV exported");
  }
  function createFolder(){if(!newFolder.trim())return;setCustomFolders(old=>[...old,newFolder.trim()]);setNewFolder("");setShowFolder(false);notify("Folder created in this demo");}
  function changePermission(){if(current){addEvent(`Permission changed to ${permission}`,current.name);setShowPermissions(false);notify(`${role} access updated in this demo`);}}
  function nav(name:string,icon:React.ReactNode){return <button key={name} onClick={()=>{setSection(name);if(name==="Activity log")setShowActivity(true)}} className={`nav-item ${section===name?"active":""}`}>{icon}<span>{name}</span>{name==="Documents"&&<span className="ml-auto text-xs">{docs.length}</span>}</button>}
  return <div className={dark?"app-shell dark":"app-shell"}>
    <div className="layout grid min-h-screen" style={{gridTemplateColumns:"238px minmax(0,1fr)"}}>
      <aside className="sidebar border-r p-4 flex flex-col gap-7" style={{borderColor:"var(--line)",background:"var(--panel)"}}>
        <div className="flex items-center gap-3 px-2 pt-1"><div className="grid place-items-center w-10 h-10 rounded-xl text-white" style={{background:"var(--accent)"}}><LockKeyhole size={21}/></div><div><div className="font-bold tracking-tight">vaultroom</div><div className="text-xs muted">SECURE WORKSPACE</div></div></div>
        <div><div className="px-3 mb-2 text-xs muted font-semibold tracking-wider">WORKSPACE</div>{nav("Overview",<Home size={18}/>)}{nav("Documents",<Folder size={18}/>)}{nav("Members",<Users size={18}/>)}{nav("Activity log",<Activity size={18}/>)}{nav("Settings",<Settings size={18}/>)}</div>
        <div className="side-extra mt-auto panel p-3"><div className="flex items-center gap-2 mb-3"><HardDrive size={16} className="muted"/><span className="text-sm font-semibold">Storage</span></div><div className="flex justify-between text-xs mb-2"><span className="muted">Used in demo</span><b>7.2 / 20 GB</b></div><div className="h-2 rounded-full overflow-hidden" style={{background:"var(--line)"}}><div className="h-full rounded-full" style={{width:"36%",background:"var(--accent)"}}/></div><p className="text-xs muted mt-3">Demo storage meter</p></div>
        <div className="flex items-center gap-3 px-2"><div className="w-9 h-9 rounded-full grid place-items-center font-bold text-sm" style={{background:"#e5e1ff",color:"#5546e8"}}>SR</div><div className="min-w-0"><div className="text-sm font-semibold">Sharon Reena</div><div className="text-xs muted">Workspace admin · Demo</div></div><ChevronDown size={15} className="ml-auto muted"/></div>
      </aside>
      <main className="min-w-0">
        <header className="px-5 md:px-8 py-4 flex items-center gap-4 border-b sticky top-0 z-10" style={{borderColor:"var(--line)",background:"var(--panel)"}}>
          <div className="flex-1"><div className="text-xs muted mb-1">Workspace / <span style={{color:"var(--text)"}}>{section}</span></div><div className="text-lg font-bold">{section==="Overview"?"Workspace overview":section==="Documents"?"Document room":section}</div></div>
          <button className="btn hide-mobile" onClick={()=>setDark(!dark)} title="Toggle theme">{dark?<Sun size={17}/>:<Moon size={17}/>}</button><button className="btn" onClick={()=>setShowActivity(true)} title="Notifications"><Bell size={17}/><span className="hidden md:inline text-sm">Activity</span></button><button className="w-9 h-9 rounded-full grid place-items-center font-bold text-sm" style={{background:"#e5e1ff",color:"#5546e8"}}>SR</button>
        </header>
        <div className="p-5 md:p-8 space-y-6">
          {section==="Overview" ? <div className="space-y-6"><div><h1 className="text-2xl font-bold">Good evening, Sharon</h1><p className="muted mt-1">Here’s what’s happening in your secure workspace.</p></div><div className="grid grid-cols-1 md:grid-cols-3 gap-4">{[["Total documents",String(docs.length),"Files in this room"],["Pending review",String(docs.filter(d=>d.status!=="Reviewed").length),"Need attention"],["Activity events",String(events.length),"Recorded in demo"]].map(([label,value,desc])=><div className="panel p-5" key={label}><div className="muted text-sm">{label}</div><div className="text-3xl font-bold mt-3">{value}</div><div className="muted text-xs mt-2">{desc}</div></div>)}</div><button className="btn btn-primary" onClick={()=>setSection("Documents")}>Open documents <ChevronRight size={16}/></button></div> :
          section==="Members" ? <div className="space-y-5"><div><h1 className="text-2xl font-bold">Room members</h1><p className="muted mt-1">Sample roles and access management controls.</p></div><div className="panel overflow-hidden"><table><thead><tr><th>MEMBER</th><th>ROLE</th><th>STATUS</th><th>ACCESS</th></tr></thead><tbody>{[["Sharon Reena","Admin","Active","Full access"],["Compliance Officer","Compliance Officer","Active","Review & flag"],["External Advisor","Advisor","Invited","View only"],["Audit Partner","Auditor","Active","View & download"]].map(m=><tr key={m[0]}><td className="font-semibold">{m[0]}</td><td>{m[1]}</td><td><span className={`pill ${m[2]==="Active"?"pill-green":"pill-amber"}`}>{m[2]}</span></td><td className="muted">{m[3]}</td></tr>)}</tbody></table></div><button className="btn btn-primary" onClick={()=>notify("Demo only: connect a backend to send invitations")}><Users size={16}/> Invite member</button></div> :
          section==="Settings" ? <div className="space-y-5"><h1 className="text-2xl font-bold">Workspace settings</h1><div className="panel p-5 max-w-2xl"><div className="font-semibold mb-2">Appearance</div><p className="muted text-sm mb-4">Switch between light and dark mode.</p><button className="btn" onClick={()=>setDark(!dark)}>{dark?<Sun size={16}/>:<Moon size={16}/>} Toggle theme</button><div className="border-t my-5" style={{borderColor:"var(--line)"}}/><div className="font-semibold mb-2">Security notice</div><p className="muted text-sm">This internship prototype uses local demo state only. Authentication, server-side authorization, encrypted storage, and real audit persistence are not implemented.</p></div></div> :
          <><div className="flex flex-wrap gap-4 items-start justify-between"><div><h1 className="text-2xl font-bold">Document room</h1><p className="muted mt-1">Manage, review, and securely organize deal documents.</p></div><div className="flex gap-2"><button className="btn" onClick={()=>setShowFolder(true)}><FolderPlus size={16}/> New folder</button><button className="btn btn-primary" onClick={()=>setShowUpload(true)}><CloudUpload size={17}/> Upload files</button></div></div>
            <div className="grid grid-cols-1 md:grid-cols-3 gap-4">{[["Total documents",String(docs.length),<FileText size={18}/>],["Pending review",String(docs.filter(d=>d.status!=="Reviewed").length),<Clock3 size={18}/>],["Flagged items",String(docs.filter(d=>d.status==="Flagged").length),<AlertTriangle size={18}/>]].map(([label,value,icon])=><div className="panel p-4 flex items-center gap-4" key={String(label)}><div className="w-11 h-11 rounded-xl grid place-items-center" style={{background:"#5546e812",color:"var(--accent)"}}>{icon}</div><div><div className="muted text-sm">{label}</div><div className="text-2xl font-bold mt-1">{value}</div></div></div>)}</div>
            <div className="content-grid grid gap-5" style={{gridTemplateColumns:previewId?"minmax(0,1.5fr) minmax(300px,1fr)":"minmax(0,1fr)"}}>
              <div className="panel overflow-hidden min-w-0"><div className="p-4 flex flex-wrap gap-3 items-center border-b" style={{borderColor:"var(--line)"}}><div className="relative flex-1 min-w-40"><Search size={16} className="absolute left-3 top-3 muted"/><input className="field pl-9" value={query} onChange={e=>setQuery(e.target.value)} placeholder="Search files or owners..."/></div><button className="btn" onClick={exportCSV}><Download size={16}/><span className="hidden sm:inline">Export</span></button></div>
                <div className="px-4 py-3 flex flex-wrap gap-2 items-center border-b" style={{borderColor:"var(--line)"}}><select className="field" style={{width:"auto",minWidth:145}} value={folder} onChange={e=>setFolder(e.target.value)}>{["All documents",...allFolders].map(f=><option key={f}>{f}</option>)}</select><select className="field" style={{width:"auto",minWidth:140}} value={sensitivity} onChange={e=>setSensitivity(e.target.value)}>{["All levels","Confidential","Public","Internal Only","Restricted"].map(x=><option key={x}>{x}</option>)}</select><select className="field ml-auto" style={{width:"auto",minWidth:130}} value={sort} onChange={e=>setSort(e.target.value)}><option value="name">Sort: Name</option><option value="date">Sort: Date</option><option value="type">Sort: File type</option><option value="sensitivity">Sort: Sensitivity</option></select></div>
                <div className="px-4 py-3 flex items-center justify-between"><span className="text-sm muted">{filtered.length} documents</span>{selected.length>0&&<div className="flex gap-2"><span className="text-sm muted self-center">{selected.length} selected</span><button className="btn" onClick={()=>notify("Bulk action is a demo")}><MoreHorizontal size={16}/> Actions</button></div>}</div>
                <div className="overflow-x-auto"><table><thead><tr><th><input type="checkbox" aria-label="Select all" checked={filtered.length>0&&filtered.every(d=>selected.includes(d.id))} onChange={e=>setSelected(e.target.checked?filtered.map(d=>d.id):[])}/></th><th>NAME</th><th className="hide-mobile">SENSITIVITY</th><th className="hide-mobile">STATUS</th><th></th></tr></thead><tbody>{filtered.map(d=><tr key={d.id} onDoubleClick={()=>setPreviewId(d.id)}><td><input type="checkbox" aria-label={`Select ${d.name}`} checked={selected.includes(d.id)} onChange={()=>toggleSelect(d.id)}/></td><td><button className="flex gap-3 items-center text-left" onClick={()=>{setPreviewId(d.id);addEvent("Viewed",d.name)}}>{fileIcon(d.type)}<span><span className="block font-semibold">{d.name}</span><span className="block text-xs muted mt-1">{d.size} · {d.modified}</span></span></button></td><td className="hide-mobile"><span className={`pill ${d.sensitivity==="Confidential"||d.sensitivity==="Restricted"?"pill-red":d.sensitivity==="Public"?"pill-green":"pill-purple"}`}>{d.sensitivity}</span></td><td className="hide-mobile"><span className={`pill ${d.status==="Reviewed"?"pill-green":d.status==="Flagged"?"pill-red":"pill-amber"}`}>{d.status}</span></td><td><button className="p-2 rounded-lg" title="Preview" onClick={()=>setPreviewId(d.id)}><Eye size={16}/></button></td></tr>)}</tbody></table>{filtered.length===0&&<div className="p-10 text-center muted">No files match these filters.</div>}</div>
                <div className="p-4 border-t flex items-center justify-between" style={{borderColor:"var(--line)"}}><span className="text-xs muted">Demo file room · changes are temporary</span><button className="btn" onClick={()=>setShowActivity(true)}><Activity size={16}/> Audit log</button></div>
              </div>
              {current&&<div className="panel overflow-hidden self-start"><div className="p-4 border-b flex items-center justify-between" style={{borderColor:"var(--line)"}}><div className="font-semibold flex items-center gap-2"><Eye size={17}/> Document preview</div><button className="p-1 rounded-lg" onClick={()=>setPreviewId(null)}><X size={17}/></button></div><div className="p-5"><div className="flex items-center gap-3 mb-4">{fileIcon(current.type)}<div className="min-w-0"><div className="font-semibold text-sm break-words">{current.name}</div><div className="text-xs muted mt-1">{current.size} · {current.type}</div></div></div><div className="rounded-xl p-4 min-h-52 whitespace-pre-wrap text-sm leading-6 overflow-auto" style={{background:"var(--bg)",border:"1px solid var(--line)",maxHeight:330}}>{current.preview.replaceAll("\\n","\\n")}</div><div className="mt-4 space-y-3"><div className="flex justify-between text-sm"><span className="muted">Owner</span><b>{current.owner}</b></div><div className="flex justify-between text-sm gap-3"><span className="muted">Sensitivity</span><span className={`pill ${current.sensitivity==="Confidential"||current.sensitivity==="Restricted"?"pill-red":"pill-purple"}`}>{current.sensitivity}</span></div><div className="flex justify-between text-sm"><span className="muted">Folder</span><b>{current.folder}</b></div></div><div className="grid grid-cols-2 gap-2 mt-5"><button className="btn" onClick={()=>{setShowPermissions(true)}}><ShieldCheck size={15}/> Permissions</button><button className="btn" onClick={()=>{addEvent("Downloaded",current.name);notify("Demo download event recorded")}}><Download size={15}/> Log download</button></div><button className="btn w-full mt-2" onClick={()=>{const next=current.sensitivity==="Confidential"?"Internal Only":"Confidential";setDocs(ds=>ds.map(d=>d.id===current.id?{...d,sensitivity:next}:d));addEvent("Sensitivity changed",current.name);notify(`Sensitivity changed to ${next}`)}}><SlidersHorizontal size={15}/> Toggle sensitivity tag</button></div></div>}
            </div>
          </>}
        </div>
      </main>
    </div>
    {toast&&<div className="fixed bottom-5 left-1/2 -translate-x-1/2 z-50 px-4 py-3 rounded-xl shadow-lg text-sm text-white" style={{background:"#202536"}}>{toast}</div>}
    {showUpload&&<Modal title="Upload documents" close={()=>setShowUpload(false)}><div className="space-y-4"><div className="rounded-xl border-2 border-dashed p-8 text-center" style={{borderColor:"var(--line)"}}><CloudUpload size={30} className="mx-auto mb-3 muted"/><div className="font-semibold">Choose files to add</div><p className="muted text-sm mt-1">Files stay in this browser demo; nothing is sent to a server.</p><input ref={uploadRef} type="file" multiple className="mt-4 field" onChange={e=>handleFiles(e.target.files)}/></div><button className="btn w-full" onClick={()=>uploadRef.current?.click()}><Upload size={16}/> Browse files</button></div></Modal>}
    {showFolder&&<Modal title="Create folder" close={()=>setShowFolder(false)}><div className="space-y-4"><label className="text-sm font-semibold">Folder name<input className="field mt-2" value={newFolder} onChange={e=>setNewFolder(e.target.value)} placeholder="e.g. Board materials"/></label><button className="btn btn-primary w-full" onClick={createFolder}>Create folder</button></div></Modal>}
    {showPermissions&&current&&<Modal title="Permission editor" close={()=>setShowPermissions(false)}><div className="space-y-4"><p className="text-sm muted">Demo permissions for <b>{current.name}</b></p><label className="text-sm font-semibold block">Role<select className="field mt-2" value={role} onChange={e=>setRole(e.target.value)}>{roles.map(r=><option key={r}>{r}</option>)}</select></label><label className="text-sm font-semibold block">Access level<select className="field mt-2" value={permission} onChange={e=>setPermission(e.target.value)}>{["View","Edit","Share","View & download","No access"].map(r=><option key={r}>{r}</option>)}</select></label><div className="rounded-xl p-3 text-sm flex gap-2" style={{background:"var(--bg)"}}><ShieldCheck size={18} className="shrink-0"/><span>Changes update the demo activity log only. Server-side access control is not implemented.</span></div><button className="btn btn-primary w-full" onClick={changePermission}><Check size={16}/> Save demo permission</button></div></Modal>}
    {showActivity&&<div className="fixed inset-0 z-40 bg-black/40" onClick={()=>setShowActivity(false)}><aside className="absolute right-0 top-0 h-full w-full max-w-md p-5 overflow-auto" style={{background:"var(--panel)"}} onClick={e=>e.stopPropagation()}><div className="flex justify-between items-center mb-2"><div><h2 className="text-xl font-bold">Activity audit log</h2><p className="muted text-sm mt-1">Recent document room events</p></div><button className="btn" onClick={()=>setShowActivity(false)}><X size={17}/></button></div><div className="mt-6 space-y-5">{events.map(ev=><div className="flex gap-3" key={ev.id}><div className="w-9 h-9 rounded-full grid place-items-center shrink-0" style={{background:"#5546e812",color:"var(--accent)"}}><Activity size={16}/></div><div className="flex-1"><div className="font-semibold text-sm">{ev.action}</div><div className="text-sm muted mt-1">{ev.file}</div><div className="text-xs muted mt-2">{ev.user} · {ev.time}</div></div></div>)}</div><p className="muted text-xs mt-8">Events are kept in local React state and reset when the page reloads.</p></aside></div>}
  </div>;
}

function Modal({title,close,children}:{title:string;close:()=>void;children:React.ReactNode}){
  return <div className="fixed inset-0 z-50 bg-black/45 grid place-items-center p-4" onClick={close}><div className="panel w-full max-w-md p-5 shadow-2xl" onClick={e=>e.stopPropagation()}><div className="flex items-center justify-between mb-5"><h2 className="text-lg font-bold">{title}</h2><button className="p-1 rounded-lg" onClick={close}><X size={18}/></button></div>{children}</div></div>;
}
