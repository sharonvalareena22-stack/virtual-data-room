import type { Metadata } from "next";
import "./globals.css";

export const metadata: Metadata = {
  title: "Vaultroom — Virtual Data Room",
  description: "Secure workspace prototype for document collaboration.",
};

export default function RootLayout({ children }: Readonly<{ children: React.ReactNode }>) {
  return <html lang="en"><body>{children}</body></html>;
}